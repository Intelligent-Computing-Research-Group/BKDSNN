from .lsq import LsqQuan
from .quantizer import IdentityQuan
